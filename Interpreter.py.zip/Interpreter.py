import os
import numpy as np
from random import *

# read file
files = os.listdir('data')

for file in files:
	print("Working on file {0}".format(file))
	with open('data/' + file,"r") as opened_file:
		i = 0
		photos = []
		# interprete the data
		for line in opened_file:
			if i == 0:
				number_of_photos = line.split(" ")[0]
				print(number_of_photos)
			else:
				photo = {}
				vals = line.split(' ')
				photo['direction'] = vals[0]
				vals[-1] = vals[-1].replace('\n','')
				photo['tags'] = vals[2:]
				photos.append(photo)
			i += 1
	# solve the data
	solution = []
	keys = list(range(len(photos)))
	while(len(keys) > 1):
		index = randint(0,len(keys) - 1)
		if photos[keys[index]]['direction'] == 'V':
			rep = 0
			while(True):
				indexTwo = randint(0,len(keys) - 1)
				if photos[keys[indexTwo]] == 'V' and indexTwo != index:
					solution.append((keys[index],keys[indexTwo]))
					del keys[indexTwo]
					del keys[index]
					break
				rep += 1
				if rep == 10:
					solution.append(keys[index])
					del keys[index]
					break
		else:
			solution.append(keys[index])
			del keys[index]
	# generate file
	with open('solution/' + file,'w+') as f:
		for elem in solution:
			if isinstance(elem, int):
				f.write("{}\n".format(elem))
			else:
				f.write("{} {}\n".format(elem[0],elem[1]))
